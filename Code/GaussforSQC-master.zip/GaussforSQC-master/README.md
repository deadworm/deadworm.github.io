# GaussforSQC
This is a code for calculating Second Quantization Coefficients by Gauss Basis Sets

For Windows, put all files in the same directory, and Microsoft Visual Studio can create an .exe file.

For Linux, there are some functions need to be adjusted, and I give a code of this version in another folder named LinuxV.

There is a sample in a folder named Sample where you can see how to use this code.
