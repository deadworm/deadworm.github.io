%在这个文件中将哈密顿量的参数设定好，并将e指数形式的哈密顿量的矩阵形式写出来

a=1;    %设定跃迁矩阵的值
b=4;   %设定库伦排斥项的值
mu=0;
I=eye(n);

t=zeros(n); %初始化t矩阵

for ix=1:nx
    for iy=1:ny
        for jx=1:nx
            for jy=1:ny
                if(ix==jx&&iy==jy)  %化学势部分
                    t((ix-1)*ny+iy,(jx-1)*ny+jy)=mu;
                end
                if((abs(ix-jx)==1&&iy==jy)||(abs(iy-jy)==1&&ix==jx))    %非周期部分
                    t((ix-1)*ny+iy,(jx-1)*ny+jy)=a;
                end
%                 if((abs(ix-jx)==nx-1&&iy==jy)||(abs(iy-jy)==ny-1&&ix==jx))    %周期部分
%                     t((ix-1)*nx+iy,(jx-1)*nx+jy)=a;
%                 end
            end
        end
    end
end

dHt=expm(-dt/2*t);   %得到半跃迁矩阵的迭代矩阵，排斥矩阵定义在函数中

dHT=expm(-dt*t);    %用于计算有限温度的矩阵

























