clear;

nx=2;
ny=1;
n=nx*ny;   %设定格点的维数
Nup=1;    %设定up粒子数
Ndn=1;    %设定dn粒子数
tm=1;   %给出试探波函数的行列式数
wmax=400;   %设定行列式个数
dt=0.01;   %设定步进的大小

itv=40;     %设定采样间隔
inorm=5;   %设定正则化波函数的间隔
ipop=10;   %设定数量控制的间隔

iex=20;     %设定采样个数
ieq=200;    %设定开始采样点
imax=ieq+iex*itv;   %计算最大迭代次数

ex=1;   %标记采样序号
E=zeros(1,iex);     %保存能量结果

Hamiltonian;

phiup=cell(1,wmax); %初始化所有的行列式,稳定性系数,交叠,权重
phidn=cell(1,wmax);
Ov=zeros(1,wmax);
ow=zeros(1,wmax);

[X,Y]=eig(t);
phiu=zeros(n,Nup);  %以无相互作用基态波函数作试探波函数
phid=zeros(n,Ndn);
for i=1:n
    for j=1:Nup
        phiu(i,j)=X(i,j);
    end
end
for i=1:n
    for j=1:Ndn
        phid(i,j)=X(i,j);
    end
end

for i=1:imax    %迭代至预期分布
for w=1:wmax    %遍历行列式
    if(i==1)
    phiup{w}=phiu;  %初始化第w个行列式
    phidn{w}=phid;
    Ov(w)=1;
    ow(w)=1;
    end
    
    if(ow(w)>0)
    pbashu=dHt*phiup{w};    %暂时保存作用一次后的行列式
    pbashd=dHt*phidn{w};
    
    Ovbash=imfortrial(pbashu,phiu,tm)*imfortrial(pbashd,phid,tm);
    
    phiup{w}=pbashu;
    phidn{w}=pbashd;
    ow(w)=ow(w)*Ovbash/Ov(w);
    Ov(w)=Ovbash;
    end

for in=1:n  %逐个格点作用Hv
    if(ow(w)>0)
    x=zeros(1,n);
    
    x(in)=1;    %先计算第一种情况
    biu=eU(n,dt,b,1,x);
    bid=eU(n,dt,b,-1,x);
    pbashu1=biu*phiup{w};
    pbashd1=bid*phidn{w};
    Ovbash1=imfortrial(pbashu1,phiu,tm)*imfortrial(pbashd1,phid,tm);
    Ni1=Ovbash1/Ov(w);
    
    x(in)=-1;    %再计算第二种情况
    biu=eU(n,dt,b,1,x);
    bid=eU(n,dt,b,-1,x);
    pbashu2=biu*phiup{w};
    pbashd2=bid*phidn{w};
    Ovbash2=imfortrial(pbashu2,phiu,tm)*imfortrial(pbashd2,phid,tm);
    Ni2=Ovbash2/Ov(w);
    
    ri=rand(1);
    if(ri<=Ni1/(Ni1+Ni2)&&Ni1>0)   %如果roll点小于这个比例就更新到第一种情况上去
        phiup{w}=pbashu1;
        phidn{w}=pbashd1;
        ow(w)=ow(w)*0.5*(Ni1+Ni2);
        Ov(w)=Ovbash1;
    elseif(Ni2>0)  %否则如果Ni2不为0则更新到第二种情况上去
        phiup{w}=pbashu2;
        phidn{w}=pbashd2;
        ow(w)=ow(w)*0.5*(Ni1+Ni2);
        Ov(w)=Ovbash2;
    else    %否则放弃这个行列式的权重
        ow(w)=0;
    end
    end
end

    if(ow(w)>0)
    pbashu=dHt*phiup{w};    %暂时保存作用一次后的行列式
    pbashd=dHt*phidn{w};
    
    Ovbash=imfortrial(pbashu,phiu,tm)*imfortrial(pbashd,phid,tm);
    
    phiup{w}=pbashu;
    phidn{w}=pbashd;
    ow(w)=ow(w)*Ovbash/Ov(w);
    Ov(w)=Ovbash;
    end
           
end

if(i>ieq&&mod(i,itv)==0)    %判断是否测量
E1=0;
P1=0;
for jphi=1:wmax
    Meup=(phiup{jphi}*((phiu'*phiup{jphi})^-1)*phiu');
    Medn=(phidn{jphi}*((phid'*phidn{jphi})^-1)*phid');
    for k=1:n
        for j=1:n
            if(k==j)
                E1=E1+ow(jphi)*Meup(k,k)*Medn(k,k)*b;
            end
            E1=E1+ow(jphi)*Meup(k,j)*t(j,k);
            E1=E1+ow(jphi)*Medn(k,j)*t(j,k);
        end
    end
    P1=P1+ow(jphi);
end
display(strcat('E=',num2str(E1/P1)))
E(ex)=E1/P1;
ex=ex+1;

end

if(mod(i,inorm)==0&&i~=imax)    %判断是否正则化
    for w=1:wmax
        [Qup,R_up]=qr(phiup{w},0);
        [Qdn,R_dn]=qr(phidn{w},0);
        phiup{w}=Qup;
        phidn{w}=Qdn;
        Ov(w)=Ov(w)/(det(R_up)*det(R_dn));
    end
end

if(mod(i,ipop)==0&&i~=imax)  %判断是否按权重新分配
    phiup_n=cell(1,wmax); %初始化所有的行列式,交叠,权重
    phidn_n=cell(1,wmax);
    Ov_n=zeros(1,wmax);
    
    osum=sum(ow);
    k=-rand(1);  %排除第一个一定不被抛弃的可能
    i_n=0;
    for in=1:wmax   %遍历所有的行列式
        k=k+ow(in)/osum*wmax;   %给出按权重分配得到的个数
        m=ceil(k);
        for jn=(i_n+1):m
            phiup_n{jn}=phiup{in};  %将这么多个行列式放到新的行列式集合里
            phidn_n{jn}=phidn{in};
            Ov_n(jn)=Ov(in);
        end
        i_n=m;
        ow(in)=1;   %整理完的行列式集合权重相等
    end
    phiup=phiup_n;  %将整理完的行列式更新
    phidn=phidn_n;
    Ov=Ov_n;
end

end

display('*****************')

display(strcat('E(average)=',num2str(mean(E))))

display(strcat('error=',num2str(std(E)/sqrt(iex))))

display(strcat('Exact_E(only for n=2,Nup=1,Ndn=1)=',num2str((b-sqrt(b^2+16*(a)^2))/2)))




