# tutorial_for_DMRG
There are two simple codes written in simple or explicit way respectively for pedagogical aim.

They are both written to solve ground state problem for 3-site 1/2-spin Herisenberg chain with periodical boundary.

For both of them, an ITensor library is needed. Copy one of them to directory 'ITensor/tutorial/project_template/', and change parameters in
'Makefile' as the guidance in that file. Finally, the 'make' command will give you a file can be run.

After understanding that, you can use functions in ITensor library more confidently.

The file named DMRGforQC is a code based on both ITensor and GaussforSQC. You can get the 'Hv' and 'Ht' files from GaussforSQC code, 
and just copy data in them into 'h1', 'h2' and 'v' vectors. After 'make' the file, you can run and get ground state of your system. There is something need to note that a new function 'void ac()' is created which is not exsit in original ITensor library. So you need copy the 'autompo.h' file in this project, cover the original file in 'ITensor/itensor/mps/' and 'make' it again. Or just close '//求完整基态' part in the code can also solve it.
