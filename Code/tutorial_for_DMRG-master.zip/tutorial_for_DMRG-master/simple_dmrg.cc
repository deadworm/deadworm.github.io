#include "itensor/all.h"
#include <iostream>
using namespace std;
using namespace itensor;

int main()
{
    int m=3;
    int m1=3;
    int j=1;
    auto sites = SpinHalf(m);
    auto ampo = AutoMPO(sites);
    for(;j<m1;j++)
    {
        ampo += 0.5,"S+",j,"S-",j+1;
        ampo += 0.5,"S-",j,"S+",j+1;
        ampo +=     "Sz",j,"Sz",j+1;
    }
    ampo += 0.5,"S+",j,"S-",1;
    ampo += 0.5,"S-",j,"S+",1;
    ampo +=     "Sz",j,"Sz",1;
    auto H = MPO(ampo);
    auto psi = MPS(sites);
    auto sweeps = Sweeps(5);
    sweeps.maxm()=50,50,100,100,200;
    auto e=dmrg(psi,H,sweeps);
    cout<<"ground state energy is"<<e<<endl;
    cout<<"ground state is"<<psi;
    return 0;
}
