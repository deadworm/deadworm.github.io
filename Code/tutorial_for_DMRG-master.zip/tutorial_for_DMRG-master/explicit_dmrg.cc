#include "itensor/all.h"
#include<iostream>
#include<math.h>
using namespace std;
using namespace itensor;

int main()
{
    //对波函数的svd分解
    auto i = Index("index i",2,Site);
    auto j = Index("index j",2,Site);
    auto k = Index("index k",2,Site);
    
    Real tau=5;
    auto T = randomTensor(i,j,k);
    
    //一种可能的初始化条件
    /*for(int m=1;m<3;m++)
        for(int n=1;n<3;n++)
            for(int l=1;l<3;l++)
            {
                if(m==n&&n==l&&l==1)
                    T.set(i(m),j(n),k(l),0.214);
                else
                    T.set(i(m),j(n),k(l),0.002);
            }
    */
    ITensor U1(i),S,V,Ux;
    svd(T,U1,S,V,{"Cutoff",1E-4});
    auto R=S*V;
    auto ru1 = commonIndex(R,U1);
    ITensor U2(ru1,j);
    svd(R,U2,S,V,{"Cutoff",1E-4});
    auto U3=S*V;
    T=U1*U2*U3;
    
    auto Tp = T;
    Tp.mapprime(Site,0,1);
    
    //测试分解结果
    auto u1u2 = commonIndex(U1,U2);
    auto U1p=prime(U1,u1u2);
    auto u2u3 = commonIndex(U2,U3);
    auto U2p=prime(U2,u2u3);
    auto U3p=prime(U3,u2u3);
    PrintData(U1*U1p);
    PrintData(U2*U2p);
    PrintData(U3*U3p);
    cout<<U1<<U2<<U3<<endl;
    
    //对算符的svd分解
    auto ip=prime(i);
    auto jp=prime(j);
    auto kp=prime(k);
    
    ITensor H = randomTensor(i,ip,j,jp,k,kp);
    for(int m1=1;m1<3;m1++)
        for(int n1=1;n1<3;n1++)
            for(int l1=1;l1<3;l1++)
                for(int m2=1;m2<3;m2++)
                    for(int n2=1;n2<3;n2++)
                        for(int l2=1;l2<3;l2++)
                        {
                            if((m1==m2&&n1!=n2&&l1!=l2&&n1!=l1)||(n1==n2&&m1!=m2&&l1!=l2&&m1!=l1)||(l1==l2&&m1!=m2&&n1!=n2&&m1!=n1))
                            {H.set(i(m1),ip(m2),j(n1),jp(n2),k(l1),kp(l2),0.5);
                                cout<<m1<<','<<m2<<','<<n1<<','<<n2<<','<<l1<<','<<l2<<' '<<0.5<<endl;}
                            else if(m1==m2&&m2==n1&&n1==n2&&n2==l1&&l1==l2)
                            {H.set(i(m1),ip(m2),j(n1),jp(n2),k(l1),kp(l2),0.75);
                                cout<<m1<<','<<m2<<','<<n1<<','<<n2<<','<<l1<<','<<l2<<' '<<0.75<<endl;}
                            else if(m1==m2&&n1==n2&&l1==l2)
                            {H.set(i(m1),ip(m2),j(n1),jp(n2),k(l1),kp(l2),-0.25);
                                cout<<m1<<','<<m2<<','<<n1<<','<<n2<<','<<l1<<','<<l2<<' '<<-0.25<<endl;}
                            else
                            {H.set(i(m1),ip(m2),j(n1),jp(n2),k(l1),kp(l2),0);
                                cout<<m1<<','<<m2<<','<<n1<<','<<n2<<','<<l1<<','<<l2<<' '<<0<<endl;}
                        }
    PrintData(H);   //  输出H作为测试
    
    ITensor H1(i,ip);
    svd(H,H1,S,V,{"Cutoff",1E-4});
    auto Y=S*V;
    auto yh1 = commonIndex(Y,H1);
    ITensor H2(yh1,j,jp);
    svd(Y,H2,S,V,{"Cutoff",1E-4});
    auto H3=S*V;
    H=H1*H2*H3;
    
    //测试分解结果
    auto h1h2 = commonIndex(H1,H2);
    auto H1p=prime(H1,h1h2);
    auto h2h3 = commonIndex(H2,H3);
    auto H2p=prime(H2,h2h3);
    auto H3p=prime(H3,h2h3);
    PrintData(H1*H1p);
    PrintData(H2*H2p);
    PrintData(H3*H3p);
    cout<<H1<<H2<<H3<<endl;
    
    //求平均值
    cout<<"平均值测试"<<(Tp*H*T).real()/(T*T).real()<<endl;
    
    //DMRG优化第三项
    auto L=U1*U2;
    R=L;
    R.mapprime(0,1);
    auto h=L*H*R;
    
    auto psi=U3;
    
    auto eh=expHermitian(h,-tau);
    auto gs=psi;
    for(int i=0;i<100;i++)
    {
        gs=(eh*gs).noprime();
        gs=gs/norm(gs);
    }
    PrintData(gs);
    cout<<"平均值测试"<<(prime(gs)*h*gs).real()<<endl;
    cout<<"归一测试"<<((U1*U2*gs)*(U1*U2*gs))<<endl;
    PrintData(U1*U2*gs);
    
    //优化第二项
    U3=gs;
    auto U23=U3*U2;
    svd(U23,Ux,S,U3,{"Cutoff",1E-4});
    U2=Ux*S;
    L=U1*U3;
    R=L;
    R.mapprime(0,1);
    h=L*H*R;
    psi=U2;
    
    eh=expHermitian(h,-tau);
    gs=psi;
    for(int i=0;i<100;i++)
    {
        gs=(eh*gs).noprime();
        gs=gs/norm(gs);
    }
    PrintData(gs);
    cout<<"平均值测试"<<(prime(gs)*h*gs).real()<<endl;
    cout<<"归一测试"<<((U1*U3*gs)*(U1*U3*gs))<<endl;
    PrintData(U1*U3*gs);
    
    //优化第一项
    U2=gs;
    auto U12=U1*U2;
    svd(U12,Ux,S,U2,{"Cutoff",1E-4});
    U1=Ux*S;
    L=U2*U3;
    R=L;
    R.mapprime(0,1);
    h=L*H*R;
    psi=U1;
    
    eh=expHermitian(h,-tau);
    gs=psi;
    for(int i=0;i<100;i++)
    {
        gs=(eh*gs).noprime();
        gs=gs/norm(gs);
    }
    PrintData(gs);
    cout<<"平均值测试"<<(prime(gs)*h*gs).real()<<endl;
    cout<<"归一测试"<<((U3*U2*gs)*(U3*U2*gs))<<endl;
    PrintData(U3*U2*gs);
    
    return 0;
}
